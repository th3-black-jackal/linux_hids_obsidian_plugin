# HIDS SIEM Fetcher (Obsidian plugin)

Pulls HIDS detection **events** and **alerts** from your project's **SIEM Read
API** (the Django `siem_api` app) straight into Obsidian notes. Built against
`SIEM_API_DOCUMENTATION.md` — same endpoints, filters, auth, and class mapping
the Qt/QML desktop app uses.

## What it does

- **Fetch alerts and events into a new note** — each fetch creates a timestamped
  note with YAML frontmatter, an optional aggregate summary (from
  `/api/siem/events/stats/`), and a table of events (time, host, class,
  confidence, alert flag, topic, id).
- **Search by latest events (timestamp)** — order by `event_time`/`received_at`,
  pull the newest first, or do an **incremental sync** that only grabs events
  newer than the last note you generated (uses a stored `received_at`
  watermark + the API's `since` filter).

## Commands

Open the command palette (`Ctrl/Cmd-P`) and search "SIEM":

| Command | Filter used |
|---|---|
| Fetch latest events into new note | `ordering=-event_time` |
| Fetch latest alerts into new note | `type=alert&ordering=-event_time` |
| Fetch events from the last 24 hours | `hours=24&ordering=-event_time` |
| Fetch alerts from the last 7 days | `type=alert&days=7&ordering=-event_time` |
| Fetch events since last sync (incremental) | `since=<watermark>&ordering=event_time` |
| Fetch events with custom filters… | opens a dialog (time range, type, host, min-confidence, ordering) |

There's also a **ribbon icon** (shield) that opens the custom-filter dialog.

## Install

This folder is a ready-to-use plugin (`manifest.json` + `main.js` + `styles.css`).

1. Copy the whole `hids-siem-fetcher/` folder into your vault at:
   `<your-vault>/.obsidian/plugins/hids-siem-fetcher/`
2. In Obsidian: **Settings → Community plugins**, enable **HIDS SIEM Fetcher**
   (turn off *Restricted/Safe mode* first if needed).
3. Open the plugin's settings and fill in:
   - **Backend base URL** — e.g. `http://192.168.1.50:8000` (no `/api/siem`).
   - **API token** — sent as `Authorization: Token <token>` on every request
     (see API doc §2; confirm token issuance with the backend owner).

## Settings

- **Notes folder** / **Filename prefix** — where notes are written and how
  they're named (`<prefix> <label> <YYYY-MM-DD HHmmss>.md`).
- **Page size** (max 500) / **Max pages** — how much to pull. The plugin follows
  the API's `next` links up to *Max pages*; if more remain, the note says so.
- **Convert times to local** — display in local time; filters are always sent in
  UTC as the API requires.
- **Include summary** — add the `stats/` aggregate block to each note.
- **Open note after creating** / **Last sync watermark** (with reset).

## Notes on the API

- All endpoints are read-only GET; the plugin never writes to the backend.
- Requests use Obsidian's `requestUrl` (no browser CORS restriction).
- Errors are surfaced as notices: 401 (bad token), 400 (the offending filter
  field is named), 404, and network failures.

## Build from source

```bash
npm install
npm run build      # type-checks, then bundles main.ts -> main.js
npm run dev        # watch mode
```

Requires Node 16+. Only `manifest.json`, `main.js`, and `styles.css` are needed
at runtime.
