import {
  App,
  Plugin,
  PluginSettingTab,
  Setting,
  Notice,
  Modal,
  TFile,
  TFolder,
  normalizePath,
  requestUrl,
  RequestUrlResponse,
  moment,
} from "obsidian";

/* =========================================================================
 * Types mirroring the SIEM Read API (SIEM_API_DOCUMENTATION.md §3)
 * ========================================================================= */

interface SiemEvent {
  id: number;
  host: string;
  event_time: string;
  received_at: string;
  class_idx: number;
  class_name: string;
  confidence: number;
  alert: boolean;
  source_topic: string;
}

interface Paginated<T> {
  count: number;
  next: string | null;
  previous: string | null;
  results: T[];
}

interface SiemStats {
  total: number;
  alerts: number;
  by_class: { class_name: string; count: number }[];
  by_host: { host: string; count: number }[];
}

type FilterValue = string | number | boolean | undefined | null;
type Filters = Record<string, FilterValue>;

/* Class index -> name, per the project mapping (API doc §3.5). */
const CLASS_NAMES = [
  "normal",
  "ransomware",
  "thetick",
  "bashlite",
  "httpbackdoor",
  "beurk",
  "backdoor",
  "bdvl",
  "xmrig",
];

/* =========================================================================
 * Settings
 * ========================================================================= */

interface SiemSettings {
  baseUrl: string;
  token: string;
  notesFolder: string;
  filenamePrefix: string;
  pageSize: number;
  maxPages: number;
  localTime: boolean;
  openAfterCreate: boolean;
  includeStats: boolean;
  lastSync: string; // ISO-8601 of newest received_at we have written
}

const DEFAULT_SETTINGS: SiemSettings = {
  baseUrl: "http://localhost:8000",
  token: "",
  notesFolder: "SIEM",
  filenamePrefix: "SIEM",
  pageSize: 100,
  maxPages: 10,
  localTime: true,
  openAfterCreate: true,
  includeStats: true,
  lastSync: "",
};

/* =========================================================================
 * API client
 * ========================================================================= */

class SiemApiError extends Error {
  status: number;
  body: unknown;
  constructor(status: number, body: unknown, message: string) {
    super(message);
    this.name = "SiemApiError";
    this.status = status;
    this.body = body;
  }
}

function describeFieldErrors(body: unknown): string {
  if (!body || typeof body !== "object") return "invalid filter value";
  const parts: string[] = [];
  for (const [k, v] of Object.entries(body as Record<string, unknown>)) {
    const msg = Array.isArray(v) ? v.join(", ") : String(v);
    parts.push(`${k}: ${msg}`);
  }
  return parts.length ? parts.join("; ") : "bad request";
}

class SiemClient {
  constructor(private settings: SiemSettings) {}

  private root(): string {
    return this.settings.baseUrl.replace(/\/+$/, "");
  }

  private buildQuery(filters: Filters): string {
    const parts: string[] = [];
    for (const [k, v] of Object.entries(filters)) {
      if (v === undefined || v === null || v === "") continue;
      parts.push(`${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`);
    }
    return parts.length ? "?" + parts.join("&") : "";
  }

  private async get<T>(url: string): Promise<T> {
    if (!this.settings.token) {
      throw new SiemApiError(0, null, "No API token set — configure it in plugin settings.");
    }
    let res: RequestUrlResponse;
    try {
      res = await requestUrl({
        url,
        method: "GET",
        headers: { Authorization: `Token ${this.settings.token}` },
        throw: false,
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      throw new SiemApiError(0, null, `Network error reaching ${url} — ${msg}`);
    }

    if (res.status === 401) {
      throw new SiemApiError(401, null, "401 Unauthorized — token missing or invalid.");
    }
    if (res.status === 404) {
      throw new SiemApiError(404, null, "404 Not found.");
    }
    if (res.status === 400) {
      let body: unknown = null;
      try {
        body = res.json;
      } catch {
        body = res.text;
      }
      throw new SiemApiError(400, body, "400 Bad Request — " + describeFieldErrors(body));
    }
    if (res.status < 200 || res.status >= 300) {
      throw new SiemApiError(res.status, res.text, `HTTP ${res.status}`);
    }
    try {
      return res.json as T;
    } catch {
      throw new SiemApiError(res.status, res.text, "Response was not valid JSON.");
    }
  }

  listEventsPage(filters: Filters): Promise<Paginated<SiemEvent>> {
    return this.get<Paginated<SiemEvent>>(
      this.root() + "/api/siem/events/" + this.buildQuery(filters)
    );
  }

  fetchUrl(url: string): Promise<Paginated<SiemEvent>> {
    return this.get<Paginated<SiemEvent>>(url);
  }

  stats(filters: Filters): Promise<SiemStats> {
    return this.get<SiemStats>(
      this.root() + "/api/siem/events/stats/" + this.buildQuery(filters)
    );
  }

  /**
   * Fetch the first page, then follow `next` (which already carries the
   * active filters, per API doc §7.5) up to `maxPages`.
   */
  async collectEvents(
    filters: Filters,
    maxPages: number
  ): Promise<{ events: SiemEvent[]; total: number; truncated: boolean }> {
    const first = await this.listEventsPage({ ...filters, page_size: this.settings.pageSize });
    const events: SiemEvent[] = [...first.results];
    let next = first.next;
    let pages = 1;
    while (next && pages < maxPages) {
      const p = await this.fetchUrl(next);
      events.push(...p.results);
      next = p.next;
      pages++;
    }
    return { events, total: first.count, truncated: !!next };
  }
}

/* =========================================================================
 * Note rendering
 * ========================================================================= */

function fmtTime(iso: string, local: boolean): string {
  if (!iso) return "";
  const m = moment(iso);
  if (!m.isValid()) return iso;
  return local
    ? m.local().format("YYYY-MM-DD HH:mm:ss")
    : m.utc().format("YYYY-MM-DD HH:mm:ss[Z]");
}

function escapeCell(s: string): string {
  return String(s).replace(/\|/g, "\\|").replace(/\n/g, " ");
}

function eventsTable(events: SiemEvent[], local: boolean): string {
  const header =
    "| Time | Host | Class | Conf. | Alert | Topic | ID |\n" +
    "|------|------|-------|-------|-------|-------|----|";
  const rows = events.map((e) => {
    const time = fmtTime(e.event_time, local);
    const conf = Number.isFinite(e.confidence)
      ? (e.confidence * 100).toFixed(1) + "%"
      : "—";
    const alert = e.alert ? "🔴 yes" : "—";
    return `| ${escapeCell(time)} | ${escapeCell(e.host)} | ${escapeCell(
      e.class_name
    )} | ${conf} | ${alert} | ${escapeCell(e.source_topic)} | ${e.id} |`;
  });
  return [header, ...rows].join("\n");
}

function statsSection(stats: SiemStats): string {
  const cls =
    stats.by_class.length > 0
      ? stats.by_class.map((c) => `- ${c.class_name}: **${c.count}**`).join("\n")
      : "- (none)";
  const hosts =
    stats.by_host.length > 0
      ? stats.by_host.map((h) => `- ${h.host}: **${h.count}**`).join("\n")
      : "- (none)";
  return (
    `## Summary\n\n` +
    `- **Total events:** ${stats.total}\n` +
    `- **Confirmed alerts:** ${stats.alerts}\n\n` +
    `**By class**\n${cls}\n\n` +
    `**By host**\n${hosts}\n`
  );
}

function describeFilters(filters: Filters): string {
  const parts: string[] = [];
  for (const [k, v] of Object.entries(filters)) {
    if (v === undefined || v === null || v === "") continue;
    parts.push(`${k}=${v}`);
  }
  return parts.length ? parts.join(", ") : "none";
}

function yamlEscape(s: string): string {
  return `"${String(s).replace(/"/g, '\\"')}"`;
}

interface NoteInput {
  label: string;
  filters: Filters;
  events: SiemEvent[];
  total: number;
  truncated: boolean;
  stats?: SiemStats;
  local: boolean;
  source: string;
}

function buildNote(input: NoteInput): string {
  const { label, filters, events, total, truncated, stats, local, source } = input;
  const now = moment();
  const nowIso = now.utc().format("YYYY-MM-DDTHH:mm:ss[Z]");
  const alertsCount = events.filter((e) => e.alert).length;

  const frontmatter = [
    "---",
    "type: siem-events",
    `title: ${yamlEscape(label)}`,
    `fetched_at: ${nowIso}`,
    `source: ${yamlEscape(source)}`,
    `filter: ${yamlEscape(describeFilters(filters))}`,
    `count: ${events.length}`,
    `alerts: ${alertsCount}`,
    "tags: [siem, hids]",
    "---",
    "",
  ].join("\n");

  const heading = `# ${label} — ${now.format("YYYY-MM-DD HH:mm")}`;

  const meta = [
    `> Source: \`${source}\``,
    `> Filter: \`${describeFilters(filters)}\``,
    `> Fetched **${events.length}** of **${total}** matching events` +
      (truncated
        ? ` _(more available — raise "Max pages" in settings to pull them all)_`
        : ``) +
      `; **${alertsCount}** confirmed alerts in this note.`,
  ].join("\n");

  const parts = [frontmatter, heading, "", meta, ""];

  if (stats) {
    parts.push(statsSection(stats), "");
  }

  parts.push("## Events");
  parts.push("");
  if (events.length > 0) {
    parts.push(eventsTable(events, local));
  } else {
    parts.push("_No events matched this filter._");
  }
  parts.push("");

  return parts.join("\n");
}

/* =========================================================================
 * Plugin
 * ========================================================================= */

export default class SiemFetcherPlugin extends Plugin {
  settings: SiemSettings;

  async onload() {
    await this.loadSettings();

    this.addSettingTab(new SiemSettingTab(this.app, this));

    // Ribbon: open the custom-filter modal.
    this.addRibbonIcon("shield-alert", "Fetch SIEM events…", () => {
      new FilterModal(this.app, this, (filters, label) =>
        this.runFetch(filters, label)
      ).open();
    });

    this.addCommand({
      id: "fetch-latest-events",
      name: "Fetch latest events into new note",
      callback: () =>
        this.runFetch({ ordering: "-event_time" }, "Latest events"),
    });

    this.addCommand({
      id: "fetch-latest-alerts",
      name: "Fetch latest alerts into new note",
      callback: () =>
        this.runFetch(
          { type: "alert", ordering: "-event_time" },
          "Latest alerts"
        ),
    });

    this.addCommand({
      id: "fetch-last-24h",
      name: "Fetch events from the last 24 hours",
      callback: () =>
        this.runFetch(
          { hours: 24, ordering: "-event_time" },
          "Events (last 24h)"
        ),
    });

    this.addCommand({
      id: "fetch-last-7d-alerts",
      name: "Fetch alerts from the last 7 days",
      callback: () =>
        this.runFetch(
          { type: "alert", days: 7, ordering: "-event_time" },
          "Alerts (last 7 days)"
        ),
    });

    this.addCommand({
      id: "fetch-since-last-sync",
      name: "Fetch events since last sync (incremental)",
      callback: () => this.runFetchSinceLastSync(),
    });

    this.addCommand({
      id: "fetch-custom",
      name: "Fetch events with custom filters…",
      callback: () =>
        new FilterModal(this.app, this, (filters, label) =>
          this.runFetch(filters, label)
        ).open(),
    });
  }

  onunload() {}

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  private async runFetchSinceLastSync() {
    if (!this.settings.lastSync) {
      new Notice(
        "No previous sync recorded yet — pulling the last 24 hours instead."
      );
      await this.runFetch(
        { hours: 24, ordering: "event_time" },
        "Events (initial sync)"
      );
      return;
    }
    await this.runFetch(
      { since: this.settings.lastSync, ordering: "event_time" },
      "Events (since last sync)"
    );
  }

  async runFetch(filters: Filters, label: string) {
    if (!this.settings.token) {
      new Notice("Set your SIEM API token in plugin settings first.", 6000);
      return;
    }

    const progress = new Notice(`Fetching “${label}”…`, 0);
    try {
      const client = new SiemClient(this.settings);
      const { events, total, truncated } = await client.collectEvents(
        filters,
        this.settings.maxPages
      );

      let stats: SiemStats | undefined;
      if (this.settings.includeStats) {
        try {
          stats = await client.stats(filters);
        } catch (e) {
          // Stats are a nice-to-have; ignore failures.
          console.warn("SIEM stats fetch failed:", e);
        }
      }

      const content = buildNote({
        label,
        filters,
        events,
        total,
        truncated,
        stats,
        local: this.settings.localTime,
        source: this.settings.baseUrl.replace(/\/+$/, ""),
      });

      const file = await this.writeNote(label, content);

      // Advance last-sync watermark to the newest received_at we've written.
      // ISO-8601 UTC strings sort lexicographically, so string max is fine.
      if (events.length > 0) {
        let newest = this.settings.lastSync;
        for (const e of events) {
          if (e.received_at > newest) newest = e.received_at;
        }
        if (newest !== this.settings.lastSync) {
          this.settings.lastSync = newest;
          await this.saveSettings();
        }
      }

      progress.hide();
      new Notice(`Wrote ${events.length} event(s) → ${file.basename}`);

      if (this.settings.openAfterCreate) {
        await this.app.workspace.getLeaf(true).openFile(file);
      }
    } catch (e) {
      progress.hide();
      if (e instanceof SiemApiError) {
        new Notice(`SIEM API: ${e.message}`, 8000);
      } else {
        const msg = e instanceof Error ? e.message : String(e);
        new Notice(`Error: ${msg}`, 8000);
      }
      console.error("SIEM fetch failed:", e);
    }
  }

  private async ensureFolder(folder: string): Promise<string> {
    const path = normalizePath(folder);
    if (path === "" || path === "/") return "";
    const existing = this.app.vault.getAbstractFileByPath(path);
    if (existing instanceof TFolder) return path;
    if (!existing) {
      try {
        await this.app.vault.createFolder(path);
      } catch (e) {
        // Race or already exists — ignore if it now exists.
        if (!(this.app.vault.getAbstractFileByPath(path) instanceof TFolder)) {
          throw e;
        }
      }
    }
    return path;
  }

  private sanitizeFilename(name: string): string {
    return name.replace(/[\\/:*?"<>|#^[\]]/g, "-").replace(/\s+/g, " ").trim();
  }

  private async writeNote(label: string, content: string): Promise<TFile> {
    const folder = await this.ensureFolder(this.settings.notesFolder);
    const stamp = moment().format("YYYY-MM-DD HHmmss");
    const prefix = this.settings.filenamePrefix
      ? this.settings.filenamePrefix + " "
      : "";
    const base = this.sanitizeFilename(`${prefix}${label} ${stamp}`);

    let filename = `${base}.md`;
    let full = folder ? `${folder}/${filename}` : filename;
    let i = 2;
    while (this.app.vault.getAbstractFileByPath(normalizePath(full))) {
      filename = `${base} (${i}).md`;
      full = folder ? `${folder}/${filename}` : filename;
      i++;
    }
    return this.app.vault.create(normalizePath(full), content);
  }
}

/* =========================================================================
 * Custom filter modal
 * ========================================================================= */

type FetchCallback = (filters: Filters, label: string) => void | Promise<void>;

class FilterModal extends Modal {
  private plugin: SiemFetcherPlugin;
  private onSubmit: FetchCallback;

  private range = "24h"; // any | 1h | 24h | 7d | custom
  private since = "";
  private until = "";
  private type = ""; // class name, "alert", "event", or empty
  private host = "";
  private minConfidence = "";
  private ordering = "-event_time";

  constructor(app: App, plugin: SiemFetcherPlugin, onSubmit: FetchCallback) {
    super(app);
    this.plugin = plugin;
    this.onSubmit = onSubmit;
  }

  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.createEl("h2", { text: "Fetch SIEM events" });

    new Setting(contentEl)
      .setName("Time range")
      .setDesc("Quick window, or choose Custom for since/until.")
      .addDropdown((d) => {
        d.addOption("any", "Any time");
        d.addOption("1h", "Last hour");
        d.addOption("24h", "Last 24 hours");
        d.addOption("7d", "Last 7 days");
        d.addOption("custom", "Custom (since/until)");
        d.setValue(this.range);
        d.onChange((v) => {
          this.range = v;
          this.renderCustomRange();
        });
      });

    this.customRangeEl = contentEl.createDiv();
    this.renderCustomRange();

    new Setting(contentEl)
      .setName("Type")
      .setDesc('Class name, "alert" (confirmed only), "event" (all), or blank.')
      .addDropdown((d) => {
        d.addOption("", "All");
        d.addOption("alert", "Confirmed alerts only");
        d.addOption("event", "All events");
        for (const name of CLASS_NAMES) d.addOption(name, name);
        d.setValue(this.type);
        d.onChange((v) => (this.type = v));
      });

    new Setting(contentEl)
      .setName("Host(s)")
      .setDesc("One or more board hostnames, comma-separated. Blank = all.")
      .addText((t) => {
        t.setPlaceholder("rpi3-sensor-01,bbb-sensor-02");
        t.setValue(this.host);
        t.onChange((v) => (this.host = v.trim()));
      });

    new Setting(contentEl)
      .setName("Min. confidence")
      .setDesc("0.0–1.0. Blank = no minimum.")
      .addText((t) => {
        t.setPlaceholder("0.9");
        t.setValue(this.minConfidence);
        t.onChange((v) => (this.minConfidence = v.trim()));
      });

    new Setting(contentEl)
      .setName("Order by")
      .addDropdown((d) => {
        d.addOption("-event_time", "Newest first (event_time)");
        d.addOption("event_time", "Oldest first (event_time)");
        d.addOption("-received_at", "Newest first (received_at)");
        d.addOption("-confidence", "Highest confidence first");
        d.setValue(this.ordering);
        d.onChange((v) => (this.ordering = v));
      });

    new Setting(contentEl)
      .addButton((b) =>
        b
          .setButtonText("Fetch into note")
          .setCta()
          .onClick(() => this.submit())
      )
      .addButton((b) => b.setButtonText("Cancel").onClick(() => this.close()));
  }

  private customRangeEl: HTMLElement;

  private renderCustomRange() {
    if (!this.customRangeEl) return;
    this.customRangeEl.empty();
    if (this.range !== "custom") return;

    new Setting(this.customRangeEl)
      .setName("Since (UTC)")
      .setDesc("ISO-8601, e.g. 2026-07-31T14:00:00Z")
      .addText((t) => {
        t.setPlaceholder("2026-07-31T14:00:00Z");
        t.setValue(this.since);
        t.onChange((v) => (this.since = v.trim()));
      });

    new Setting(this.customRangeEl)
      .setName("Until (UTC)")
      .setDesc("ISO-8601, optional.")
      .addText((t) => {
        t.setPlaceholder("2026-07-31T15:00:00Z");
        t.setValue(this.until);
        t.onChange((v) => (this.until = v.trim()));
      });
  }

  private buildFilters(): { filters: Filters; label: string } {
    const filters: Filters = { ordering: this.ordering };
    const labelBits: string[] = [];

    switch (this.range) {
      case "1h":
        filters.hours = 1;
        labelBits.push("last 1h");
        break;
      case "24h":
        filters.hours = 24;
        labelBits.push("last 24h");
        break;
      case "7d":
        filters.days = 7;
        labelBits.push("last 7d");
        break;
      case "custom":
        if (this.since) filters.since = this.since;
        if (this.until) filters.until = this.until;
        if (this.since || this.until) labelBits.push("custom range");
        break;
      case "any":
      default:
        break;
    }

    if (this.type) {
      filters.type = this.type;
      labelBits.push(this.type);
    }
    if (this.host) {
      filters.host = this.host;
      labelBits.push(this.host);
    }
    if (this.minConfidence) {
      filters.min_confidence = this.minConfidence;
      labelBits.push(`conf≥${this.minConfidence}`);
    }

    const label =
      labelBits.length > 0 ? `Events (${labelBits.join(", ")})` : "Events";
    return { filters, label };
  }

  private async submit() {
    const { filters, label } = this.buildFilters();
    this.close();
    await this.onSubmit(filters, label);
  }

  onClose() {
    this.contentEl.empty();
  }
}

/* =========================================================================
 * Settings tab
 * ========================================================================= */

class SiemSettingTab extends PluginSettingTab {
  plugin: SiemFetcherPlugin;

  constructor(app: App, plugin: SiemFetcherPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;
    containerEl.empty();

    containerEl.createEl("h2", { text: "HIDS SIEM Fetcher" });

    new Setting(containerEl)
      .setName("Backend base URL")
      .setDesc("e.g. http://192.168.1.50:8000 (no trailing /api/siem).")
      .addText((t) =>
        t
          .setPlaceholder("http://localhost:8000")
          .setValue(this.plugin.settings.baseUrl)
          .onChange(async (v) => {
            this.plugin.settings.baseUrl = v.trim();
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("API token")
      .setDesc('Sent as "Authorization: Token <token>" on every request.')
      .addText((t) => {
        t.setPlaceholder("your-token")
          .setValue(this.plugin.settings.token)
          .onChange(async (v) => {
            this.plugin.settings.token = v.trim();
            await this.plugin.saveSettings();
          });
        t.inputEl.type = "password";
      });

    new Setting(containerEl)
      .setName("Notes folder")
      .setDesc("Vault folder for generated notes (created if missing).")
      .addText((t) =>
        t
          .setPlaceholder("SIEM")
          .setValue(this.plugin.settings.notesFolder)
          .onChange(async (v) => {
            this.plugin.settings.notesFolder = v.trim();
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Filename prefix")
      .addText((t) =>
        t
          .setPlaceholder("SIEM")
          .setValue(this.plugin.settings.filenamePrefix)
          .onChange(async (v) => {
            this.plugin.settings.filenamePrefix = v.trim();
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Page size")
      .setDesc("Rows per API request (max 500 per the API).")
      .addText((t) =>
        t
          .setValue(String(this.plugin.settings.pageSize))
          .onChange(async (v) => {
            const n = parseInt(v, 10);
            if (Number.isFinite(n) && n > 0) {
              this.plugin.settings.pageSize = Math.min(n, 500);
              await this.plugin.saveSettings();
            }
          })
      );

    new Setting(containerEl)
      .setName("Max pages")
      .setDesc("How many pages to follow via `next` before stopping.")
      .addText((t) =>
        t
          .setValue(String(this.plugin.settings.maxPages))
          .onChange(async (v) => {
            const n = parseInt(v, 10);
            if (Number.isFinite(n) && n > 0) {
              this.plugin.settings.maxPages = n;
              await this.plugin.saveSettings();
            }
          })
      );

    new Setting(containerEl)
      .setName("Convert times to local")
      .setDesc("Display timestamps in local time (filters still sent in UTC).")
      .addToggle((tg) =>
        tg
          .setValue(this.plugin.settings.localTime)
          .onChange(async (v) => {
            this.plugin.settings.localTime = v;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Include summary")
      .setDesc("Add an aggregate summary (from /events/stats/) to each note.")
      .addToggle((tg) =>
        tg
          .setValue(this.plugin.settings.includeStats)
          .onChange(async (v) => {
            this.plugin.settings.includeStats = v;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Open note after creating")
      .addToggle((tg) =>
        tg
          .setValue(this.plugin.settings.openAfterCreate)
          .onChange(async (v) => {
            this.plugin.settings.openAfterCreate = v;
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Last sync watermark")
      .setDesc(
        this.plugin.settings.lastSync
          ? `Newest received_at seen: ${this.plugin.settings.lastSync}`
          : "No incremental sync recorded yet."
      )
      .addButton((b) =>
        b.setButtonText("Reset").onClick(async () => {
          this.plugin.settings.lastSync = "";
          await this.plugin.saveSettings();
          this.display();
          new Notice("Sync watermark reset.");
        })
      );
  }
}
